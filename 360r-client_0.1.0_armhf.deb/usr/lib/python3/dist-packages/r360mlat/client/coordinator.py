# -*- mode: python; indent-tabs-mode: nil -*-

# Part of 360r-client - an ADS-B multilateration client.
# Copyright 2015, Oliver Jowett <oliver@mutability.co.uk>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
This is the core of the 360R-Client.  It basically tracks one or more aircraft and sends
data to the server as needed.  Defines two classes: Aircraft (which is one tracked aircraft)
and a single instance of the Coordinator which is controls what the 360R-Client does.

The 360r-client script parses the command line switches and passes in the value so that the
Coordinator can establish connections to the local receiver (dump1090 etc), the MLAT-Server
to upload data as well as listening for any returned data too.


Coordinator.__init__

Internals:

    Coordinator.run_forever
    Coordinator.run_until
    Coordinator.heartbeat
    Coordinator.update_aircraft
    Coordinator.send_aircraft_report
    Coordinator.send_rate_report
    Coordinator.periodic_stats

Callbacks from server connection:

    Coordinator.server_connected
    Coordinator.server_disconnected
    Coordinator.server_mlat_result
    Coordinator.server_stop_sending
    Coordinator.update_receiver_filter

Callbacks from receiver input:

    Coordinator.input_connected
    Coordinator.input_disconnected
    Coordinator.input_received_messages

Handlers for receiver messages

    Coordinator.received_mode_change_event
    Coordinator.received_epoch_rollover_event
    Coordinator.received_timestamp_jump_event
    Coordinator.received_radarcape_position_event
    Coordinator.received_df_misc
    Coordinator.received_df11
    Coordinator.received_df17
    Coordinator.received_modeac

"""

import asyncore
import time
import socket
import requests
from requests.exceptions import HTTPError

# Import ModeS module compiled from C
import _modes360r
import r360mlat.profile
from r360mlat.client.util import monotonic_time, log
from r360mlat.client.stats import global_stats
from r360mlat.client.jsonclient import JsonServerConnection
from r360mlat.client.net import ReconnectingConnection

# Turn on debugging (this will show raw messages in log file)
DEBUG = False

class Aircraft:
    """One tracked aircraft."""

    def __init__(self, icao):
        # The properties of one aircraft
        self.icao = icao
        self.messages = 0
        self.last_message_time = 0
        self.last_position_time = 0
        self.even_message = None
        self.odd_message = None
        self.reported = False
        self.requested = True
        self.measurement_start = None
        self.rate_measurement_start = 0
        self.recent_adsb_positions = 0
        # Added to store the aircraft altitude
        self.altitude = None
        # Added to store whether aircraft is on the ground or airborne
        self.on_ground = False

class UdpDfUploadConnection:
    ''' A simple UDP Client '''

    def __init__(self, host, port):
        self.adsbHost    = host    # Host address
        self.adsbPort    = port    # Host port
        self.sock        = None    # Socket
        self.nextConnect = None    # Time to reconnect

        # Connect to server
        self.connect()

    def connect(self):
        ''' Configure the client to use UDP protocol with IPv4 addressing '''
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Reconnect in 5 minutes
            self.nextConnect = monotonic_time() + 300
            log("Refreshed UDP connection for ADSB data")
        except OSError as err:
            log("Failed to refresh UDP connection for ADSB data with error: {}", err)

    def disconnect(self):
       ''' Close socket '''
       try:
           self.socket.close()
           log("Closed UDP connection for ADSB data")
       except:
           # Swallow error
           return None

    def updateServer(self, adsbHost, adsbPort):
        ''' Update ADSB server details '''
        self.adsbHost = adsbHost
        self.adsbPort = adsbPort
        log("Updated ADSB server details to {0}:{1}", self.adsbHost, self.adsbPort)
        self.reconnect()

    def reconnect(self):
        ''' Close existing socket and reconnect '''
        self.disconnect()
        self.connect()
        log("ADSB server reconnected")

    def send(self, message):
        ''' Send request to a UDP Server and receive reply from it. '''

        # Convert the message into the raw message format
        msg = "*" + "".join("{:02x}".format(x) for x in message) + ";\n"

        # Attempt to send it
        try:
            # send data to server
            self.sock.sendto(msg.encode('utf-8'), (self.adsbHost, self.adsbPort))
        except OSError as err:
            log("UDP ADSB data upload failed with error: {}", err)
            # close socket
            self.reconnect()

        # See if we need to reconnect
        if monotonic_time() >= self.nextConnect:
            self.reconnect()

class Coordinator:
    # How often in seconds should we send changes to the list of seen aircraft to server
    update_interval = 5.0
    # How often in seconds should we send the full list of aircraft seen to the server
    report_interval = 30.0
    # How often in seconds between outputing 360R-Client stats to log file
    stats_interval = 900.0
    # How old in seconds before we mark a position as old
    position_expiry_age = 30.0
    # How old in seconds before we remove an aircraft from the list of seen aircraft
    expiry_age = 60.0
    # Define default altitude cutoff height
    altitude_limit = None

    def __init__(self, receiver, server, outputs, freq, allow_anon, allow_modeac, adsbHost, adsbPort, altitude_limit):
        # Define the receiver type (dump1090, SBS etc)
        self.receiver = receiver
        # Define the server that the data gets sent to
        self.server = server
        # Define the data type that the MLAT-Server will return to the client (if any)
        self.outputs = outputs
        # Contains information on clock parameters of the specified receiver
        self.freq = freq
        # Determines if anonymised aircraft in returned MLAT results will be displayed.
        # In practice this only affects MLAT's returned by FlightAware
        self.allow_anon = allow_anon
        # Determine if we will try and MLAT Mode A/C results or not.  The default seems
        # yes but once the client has synced with the server mode A/C is then turned off
        # possibily because the MLAT-Server isn't capable of doing this anyway.
        self.allow_modeac = allow_modeac
        # Store ADSB host, port and altitude limit
        self.adsbHost = adsbHost
        self.adsbPort = int(adsbPort)
        self.altitude_limit = int(altitude_limit)

        if DEBUG:
            log('Allow Mode AC in Coordinator__init__:{0}', allow_modeac)

        # Build default list of all aircraft seen
        self.aircraft = {}
        # Build default empty list of aircraft requested by the MLAT-Server
        self.requested_traffic = set()
        # Build default empty list of mode A/C codes requested by the MLAT server
        self.requested_modeac = set()
        # ? Possibly the default list of aircraft reported to the MLAT-Server ?
        self.reported = set()

        # Define which handler will process each different type of DF message
        # as well as which handler will handle any changes
        #
        # The different DF message types contain the following information:
        #
        # DF 0  - Short Air to Air (ACAS)
        #             Provides the ICAO hex code plus the vertical status and
        #             altitude code
        # STATUS:     360R-Client handles by default
        #
        # DF 4  - Surveillance (roll call)
        #             Provides the ICAO hex code, altitude code and flight status
        # STATUS:     360R-Client handles by default
        #
        # DF 5  - Surveillance (roll call) Ident Reply
        #             Provides the ICAO hex code, altitude code and flight status
        # STATUS:     360R-Client handles by default
        #
        # DF 11 - Mode S only All-Call Reply
        #             Provides the ICAO hex code plus the interogator ID if set
        # STATUS:     360R-Client uses these but via other handlers
        #
        # DF 16 - Long Air to Air ACAS (360R-Client handles by default)
        #             Provides the ICAO hex code plus the vertical status and
        #             altitude code
        # STATUS:     360R-Client handles by default
        #
        # DF 17 - 1090 Extended Squitter (360R-Client handles by default)
        #             Provides the ICAO hex code and the ADSB message
        # STATUS:     360R-Client handles by default
        #
        # DF 18 - 1090 Extended Squitter, supplimentary
        #             Provides the ICAO hex code plus any TIS-B message
        # STATUS:     360R-Client ignores by default
        #
        # DF 19 - Military Extended Squitter (360R-Client ignores by default)
        #             Provides ....
        # STATUS:     360R-Client ignores by default
        #
        # DF 20 - Comm B Altitude, Ident Reply
        #             Provides the ICAO hex code, flight status, altitude code
        #             and Comm-B message
        # STATUS:     360R-Client handles by default
        #
        # DF 21 - Comm B Altitude, Ident Reply
        #             Provides the ICAO hex code, flight status and Comm-B
        #             message
        # STATUS:     360R-Client handles by default
        #
        # DF 24 - Comm D Extended Length Message
        #             Provides the ICAO hex code and the Comm-D message
        # STATUS:     360R-Client ignores by default
        #
        # Other 'DF' codes that the 360R-Client handles but which are defined
        # interinally to indicate things that have happened
        #
        # DF 32 - Mode A/C message
        #              Provides the signal strength and Mode A or Mode C
        # STATUS:      360R-Client has a handler but it never gets triggered
        #
        # DF 33 - Timestamp Jump
        #              Sent when C decoder detects an out of sequnce timestamp
        #
        # DF 34 - Mode Change
        #              Sent when the 360R-Client changes the decoder format
        #
        # DF 35 - Epoch Rollover
        #              Sent when the timestamp counter resets to zero after hitting
        #              its maximum value
        #
        # DF 36 - Radarcape Status Message Received
        #              Sent when the C decoder receives a status message from the
        #              Radarcape containing satellite signal strengths etc
        #
        # DF 37 - Radarcape Position
        #              Sent when the Radarcape reports its own location


        # Define the handlers for the different message types that the client
        # uses to MLAT.  Selection is based on the value of the DF field within
        # the ModeS / ADSB message
        self.df_handlers = {
            _modes360r.DF_EVENT_MODE_CHANGE: self.received_mode_change_event,
            _modes360r.DF_EVENT_EPOCH_ROLLOVER: self.received_epoch_rollover_event,
            _modes360r.DF_EVENT_TIMESTAMP_JUMP: self.received_timestamp_jump_event,
            _modes360r.DF_EVENT_RADARCAPE_POSITION: self.received_radarcape_position_event,
            0: self.received_df_misc,
            4: self.received_df_misc,
            5: self.received_df_misc,
            16: self.received_df_misc,
            20: self.received_df_misc,
            21: self.received_df_misc,
            11: self.received_df11,
            17: self.received_df17,
            _modes360r.DF_MODEAC: self.received_modeac
        }
        # Timestamp for next report to MLAT-Server
        self.next_report = None
        # Timestamp for next stats report
        self.next_stats = monotonic_time() + self.stats_interval
        # Timestamp for next performance profile snapshot
        self.next_profile = monotonic_time()
        # Timestamp for next periodic aircraft update (new additions or lost aircraft
        # are uploaded inbetween)
        self.next_aircraft_update = self.last_aircraft_update = monotonic_time()
        # Possibly to do with jumping timestamps ?
        self.recent_jumps = 0

        receiver.coordinator = self
        server.coordinator = self

        # Create connection to UDP ADSB socket
        self.udpConnection = UdpDfUploadConnection(self.adsbHost, self.adsbPort)

    # internals

    def run_forever(self):
        self.run_until(lambda: False)

    def run_until(self, termination_condition):
        # Periodically checks that the client is connected to a receiver such as
        # dump1090 via a socket.  If not, keep trying and then eventually shut
        # down the client also elegantly closing connections to the MLAT-Server
        # and any local connections such as to VRS etc
        try:
            # Determine the time of the next heartbeat in seconds
            next_heartbeat = monotonic_time() + 0.5
            while not termination_condition():
                # maybe there are no active sockets and
                # we're just waiting on a timeout
                if asyncore.socket_map:
                    asyncore.loop(timeout=0.1, count=5)
                else:
                    time.sleep(0.5)

                now = monotonic_time()
                if now >= next_heartbeat:
                    next_heartbeat = now + 0.5
                    self.heartbeat(now)

        finally:
            # Disconnect any receivers (dump1090 etc)
            self.receiver.disconnect('Client shutting down')
            # Disconnect from the MLAT-Server
            self.server.disconnect('Client shutting down')

            # Close any connections to VRS etc
            for o in self.outputs:
                o.disconnect('Client shutting down')

    def heartbeat(self, now):
        # Probably sends heartbeat now to receiver, MLAT-Server and also
        # any listening processes such as VRS etc
        self.receiver.heartbeat(now)
        self.server.heartbeat(now)
        for o in self.outputs:
            o.heartbeat(now)

        # If we need to, dump out CPU profile and set time for next one
        # to 30 seconds in the future
        if now >= self.next_profile:
            self.next_profile = now + 30.0
            r360mlat.profile.dump_cpu_profiles()

        # If we need to, set next aircraft update to now plus the update
        # interval.  Then send list of aircraft currrently in view
        if now >= self.next_aircraft_update:
            self.next_aircraft_update = now + self.update_interval
            self.update_aircraft(now)

            # piggyback reporting on regular updates
            # as the reporting uses data produced by the update
            if self.next_report and now >= self.next_report:
                self.next_report = now + self.report_interval
                self.send_aircraft_report()
                self.send_rate_report(now)

        # If we need to, push out stats to the 360r-client.log file
        # and set the next update time in the future
        if now >= self.next_stats:
            self.next_stats = now + self.stats_interval
            self.periodic_stats(now)
            # Also check to see if the server to send data to or the altitude limit
            # has changed
            self.getServer()

    def update_aircraft(self, now):
        # Process aircraft the receiver has seen although since the 360R-Client
        # only tracks DF11 and DF17 messages (due to the way that messages are
        # filtered an aircraft may have been updated perhaps via a DF0, DF4, DF5
        # etc message but these would have been ignored by the 360R-Client /
        # MLAT-Server as they are not used to synchronise receivers.

        # Loop across all aircraft that the 360R-Client knows about
        for icao in self.receiver.recent_aircraft():
            # Do we know about this aircraft ?
            ac = self.aircraft.get(icao)
            # No, so create an Aircraft object
            if not ac:
                ac = Aircraft(icao)
                # Has the MLAT-Server asked for information on it ?
                ac.requested = (icao in self.requested_traffic)
                # Start measuring the message rate for this aircraft
                ac.rate_measurement_start = now
                self.aircraft[icao] = ac

            if ac.last_message_time <= self.last_aircraft_update:
                # fudge it a bit, receiver has seen messages
                # but they were all filtered
                ac.messages += 1
                ac.last_message_time = now

        # expire aircraft we have not seen for a while
        for ac in list(self.aircraft.values()):
            # If the aircraft hasn't been updated in a while then
            # remove it from the list
            if (now - ac.last_message_time) > self.expiry_age:
                del self.aircraft[ac.icao]

        # Store the current time as the last update time
        self.last_aircraft_update = now

    def send_aircraft_report(self):
        # Compares the list of aircraft that have previously been reported to
        # the MLAT-Server against the list of aircraft that we can currently
        # see.  Any new ones are reported to the server and any that have
        # been lost are also reported.  The list of reported aircraft is then
        # updated so that it's the same as the list of all aircraft currently
        # in view

        # Get a list of all aircraft where we've seen more than one message
        all_aircraft = {x.icao for x in self.aircraft.values() if x.messages > 1}

        # Build a list of any aircraft that we've seen that we haven't
        # previously reported to the MLAT-Server
        seen_ac = all_aircraft.difference(self.reported)

        # Build a list of any aircraft that we've previously reported to the
        # MLAT-Server which are no longer in our list of aircraft that we know
        # about
        lost_ac = self.reported.difference(all_aircraft)

        # If we've seen new aircraft report them to the MLAT-Server
        if seen_ac:
            self.server.send_seen(seen_ac)

        # If we've lost any aircraft report them to the MLAT-Server
        if lost_ac:
            self.server.send_lost(lost_ac)

        # Update the list of aircraft reported to the server so that it
        # contains all aircraft that the 360R-Client knows about
        self.reported = all_aircraft

    def send_rate_report(self, now):
        # Calculate how many messages we've seen from each aircraft and
        # when we started counting so that we can deterine the average
        # message rate for each one.  Upload to the MLAT-server if needed

        rate_report = {}
        # Loop across all aircraft that we've seen
        for ac in self.aircraft.values():
            # How long have we been measuring for ?
            interval = now - ac.rate_measurement_start
            # If it's more than 0 and we have recent positions then
            # calculate the message rate per second
            if interval > 0 and ac.recent_adsb_positions > 0:
                rate = 1.0 * ac.recent_adsb_positions / interval
                # Reset the count and time to now
                ac.rate_measurement_start = now
                ac.recent_adsb_positions = 0
                # Store the calculated rate
                rate_report[ac.icao] = rate

        # If we have a non-zero rate then upload it to the server
        if rate_report:
            self.server.send_rate_report(rate_report)

    def periodic_stats(self, now):
        # Updates counters for seen ADSB and MLAT aircraft and any out of
        # sequence timestamps.  Log them to the log file

        # Log the receiver and server status to the log file
        log('Receiver status: {0}', self.receiver.state)
        log('Server status:   {0}', self.server.state)
        global_stats.log_and_reset()

        # Reset counters to zero
        adsb_req = adsb_total = modes_req = modes_total = 0

        # Get current time
        now = monotonic_time()
        # Loop across all aircraft that the client knows about
        for ac in self.aircraft.values():
            # We need to see at least one message
            if ac.messages < 2:
                continue

            # If the aircraft hasn't expired increment the ADSB aircraft count
            if now - ac.last_position_time < self.position_expiry_age:
                adsb_total += 1
                # If the aircraft has been requested by the server increment that count too
                if ac.requested:
                    adsb_req += 1
            else:
                # If it's not an ADSB aircraft then it must be an MLAT one so increment
                # that counter
                modes_total += 1
                if ac.requested:
                    modes_req += 1

        # Log values to the 360r-client.log file
        log('Aircraft: {modes_req} of {modes_total} Mode S, {adsb_req} of {adsb_total} ADS-B used',
            modes_req=modes_req,
            modes_total=modes_total,
            adsb_req=adsb_req,
            adsb_total=adsb_total)

        # Log any out of sequence timestamps if needed
        if self.recent_jumps > 0:
            log('Out-of-order timestamps: {recent}', recent=self.recent_jumps)
            self.recent_jumps = 0

    # callbacks from server connection

    def server_connected(self):
        # Set up defaults once server is connected

        # List of aircraft that MLAT server has asked for information on
        self.requested_traffic = set()
        # List of mode A/C aircraft that the MLAT server has asked for information on
        self.requested_modeac = set()
        # List of aircraft newly seen by the client
        self.newly_seen = set()
        self.aircraft = {}
        self.reported = set()
        # Set timestamp of next report
        self.next_report = monotonic_time() + self.report_interval
        # If the connection failed retry again
        if self.receiver.state != 'ready':
            self.receiver.reconnect()

    def server_disconnected(self):
        # If we've lost our connection to the MLAT-Server then disconnected the local receiver too
        self.receiver.disconnect('Lost connection to multilateration server, no need for input data')
        # Reset all values
        self.next_report = None
        self.next_rate_report = None
        self.next_expiry = None

    def server_mlat_result(self, timestamp, addr, lat, lon, alt, nsvel, ewvel, vrate,
                           callsign, squawk, error_est, nstations, anon, modeac):
        # Handles aircraft positions returned by the MLAT-Server and forwards them
        # to anything that's connected such as VRS

        # Increment count of MLAT positions returned
        global_stats.mlat_positions += 1

        # If it's an anonymous position and we're suppressing those then return
        # without handling the message
        if anon and not self.allow_anon:
            return

        # If it's a Mode AC result and we're suppressing those then return without
        # handling the message
        if modeac and not self.allow_modeac:
            if DEBUG:
                log('Mode A/c position returned from server but ignored')
            return

        # Otherwise go ahead and handle the position message
        for o in self.outputs:
            o.send_position(timestamp, addr, lat, lon, alt, nsvel, ewvel, vrate,
                            callsign, squawk, error_est, nstations, anon, modeac)

    def server_start_sending(self, icao_set, modeac_set=set()):
        # The MLAT-Server can optionally return the positions of aircraft that the
        # 360R-Client has helped to locate.  We therefore need to tell the MLAT-Server
        # hex code of the MLAT aircraft that we are interested in

        # Loop over hex codes
        for icao in icao_set:
            # Get the aircraft if it exists
            ac = self.aircraft.get(icao)
            # If we have it then request it from the server
            if ac:
                ac.requested = True
        # Request an update from the MLAT-Server for these aircraft
        self.requested_traffic.update(icao_set)
        # If we allow MLAT'ing of Mode A/C aircraft then request those too
        if self.allow_modeac:
            if DEBUG:
                log('Updated list of mode A/C aircraft')
            self.requested_modeac.update(modeac_set)
        # Filter all aircraft that the 360R-Client is aware of in order to
        # build a list of MLAT aircraft
        self.update_receiver_filter()

    def server_stop_sending(self, icao_set, modeac_set=set()):
        # Tell the MLAT-Server to stop sending calculated position reports
        # for specific aircraft

        # Loop over all aircraft
        for icao in icao_set:
            # Get the aircraft if it exists
            ac = self.aircraft.get(icao)
            # If it does then don't request it from the server again
            if ac:
                ac.requested = False
        self.requested_traffic.difference_update(icao_set)
        # Tell the MLAT-Server to stop sending any mode A/C positions
        if self.allow_modeac:
            if DEBUG:
                log('Request that server stop sending Mode A/C')
            self.requested_modeac.difference_update(modeac_set)

        # Filter all aircraft that the 360R-Client is aware of in order to
        # build a list of MLAT aircraft
        self.update_receiver_filter()

    def update_receiver_filter(self):
        # Filter all aircraft that the 360R-Client is aware of in order to
        # build a list of MLAT aircraft
        now = monotonic_time()

        mlat = set()
        for icao in self.requested_traffic:
            ac = self.aircraft.get(icao)
            if not ac or (now - ac.last_position_time > self.position_expiry_age):
                # requested, and we have not seen a recent ADS-B message from it
                mlat.add(icao)

        self.receiver.update_filter(mlat)
        # The line below seems to turn off Mode A/C messages.  Not sure why -
        # perhaps because Oliver wanted it turned off it a user had accidentally
        # turned it on ?
        self.receiver.update_modeac_filter(self.requested_modeac)

    # callbacks from receiver input

    def input_connected(self):
        # Handles new connections to the local receiver
        self.server.send_input_connected()

    def input_disconnected(self):
        # Disconnect from the local receiver
        self.server.send_input_disconnected()
        # Expire everything
        self.aircraft.clear()
        self.server.send_lost(self.reported)
        self.reported.clear()

    @r360mlat.profile.trackcpu
    def input_received_messages(self, messages):
        # Reads the messages in the messages queue and, based on the message type,
        # passes it to a handler for processing.  If there's no handler then the
        # message is discarded
        now = monotonic_time()
        # Loop over all messages in the messages queue
        for message in messages:

            # The line below just outputs the local user name, DF message type, signal strength,
            # message length and the raw message in hex.  Converting the raw message from bytes
            # to hex in the way shown is not the most efficient method.  See here for the better way:
            # https://stackoverflow.com/questions/19210414/byte-array-to-hex-string
            #if DEBUG and message.address is not None:
            #    log("Message User: {0} Timestamp: {1} DF: {2} Signal: {3} Address: {4} Length: {5} Data: {6}", self.server.handshake_data['user'], message.timestamp, message.df, message.signal, '{0:06X}'.format(message.address), len(message), "".join("{:02x}".format(x) for x in message))

            #if DEBUG and message.address is None:
            #    log("Message User: {0} Timestamp: {1} DF: {2} Signal: {3} Length: {4} Data: {5}", self.server.handshake_data['user'], message.timestamp, message.df, message.signal, len(message), "".join("{:02x}".format(x) for x in message))

            # Get message handler
            handler = self.df_handlers.get(message.df)

            # If there's a message handler for this message then push the message to it
            if handler:
                handler(message, now)

    # handlers for input messages

    def received_mode_change_event(self, message, now):
        # Different receiver types have different characteristics and the user may not always
        # always select the best source of data.  The 360R-Client needs raw messages to work
        # so will switch to the correct format if needed.  This may mean that different
        # characteristics are need.  This function is called when the receiver mode has changed
        # so that the user is aware.

        # Decoder mode changed, clock parameters possibly changed
        self.freq = message.eventdata['frequency']
        self.recent_jumps = 0
        self.server.send_clock_reset(reason='Decoder mode changed to {mode}'.format(mode=message.eventdata['mode']),
                                     frequency=message.eventdata['frequency'],
                                     epoch=message.eventdata['epoch'],
                                     mode=message.eventdata['mode'])
        log("Input format changed to {mode}, {freq:.0f}MHz clock",
            mode=message.eventdata['mode'],
            freq=message.eventdata['frequency']/1e6)

    def received_epoch_rollover_event(self, message, now):
        # The 'timestamp' provided by most receivers is not a timestamp at all but is instead
        # simply an integer counter which increments with each new message.  Depending on how
        # the integer value has been defined then it's possible that the maximum value may be
        # reached so the 'timestamp' value is likely to either be reset to zero or the sign
        # bit will be flipped and reports the maximum negative number.  This value is then
        # incremented back towards zero.  This is only likely on those receiver that will be
        # left running for years without restarting and which see huge numbers of messages

        # epoch rollover, reset clock
        self.server.send_clock_reset('Epoch rollover detected')

    def received_timestamp_jump_event(self, message, now):
        # Receiver timestamps are actually a sequentially incrementing counter of raw messages.
        # In theory they should increment with each message but occasionally don't.  If we get
        # more than 10 of these alert the user via the log.  One possible explaination is that
        # the user is trying to combine more than one receiver.
        self.recent_jumps += 1
        if self.recent_jumps == 10:
            log("Warning: the timestamps provided by your receiver do not seem to be self-consistent. "
                "This can happen if you feed data from multiple receivers to a single 360r-client, which "
                "is not supported; use a separate 360r-client for each receiver.")

    def received_radarcape_position_event(self, message, now):
        # Handles a Radarcape position message decoded by the Mode S class.  Need to look at
        # that to understand it better
        self.server.send_position_update(message.eventdata['lat'],
                                         message.eventdata['lon'],
                                         message.eventdata['alt'],
                                         'egm96_meters')

    def received_df_misc(self, message, now):
        # By default the MLAT client uses just two messages types.  It uses DF17 messages to sync
        # receivers and DF11 messages are used to MLAT the aircraft.  All other messages are
        # currently ignored but it's these that we will forward to the 360Radar servers so that
        # we can track ADSB aircraft using the single client

        # Do we have an aircraft with this address ?
        ac = self.aircraft.get(message.address)
        if not ac:
            return False  # No, it's not a known ICAO

        # Is the aircraft below the altitude limit ?
        if ac.altitude is not None and ac.altitude < self.altitude_limit:
            self.udpConnection.send(message)
            if DEBUG:
                log("DF{0} {1} from {2} uploaded", message.df, message, message.address)

        # Yes so increment the message count for this aircraft
        ac.messages += 1
        # Store the last seen time
        ac.last_message_time = now

        # If it's a DF0 / 4 / 16  or 20 message retrieve the altitude value and store it
        if (message.df == 0):
            ac.altitude = message.altitude
        elif (message.df == 4):
            ac.altitude = message.altitude
        elif (message.df == 16):
            ac.altitude = message.altitude
        elif (message.df == 20):
            ac.altitude = message.altitude

        # This is where we would upload the received message via UDP

        # How many messages have we seen from it ?
        if ac.messages < 10:
            return   # Not enough so wait for more messages
        # Does the MLAT-Server suspect this is an MLAT aircraft ?
        if not ac.requested:
            return

        # It could be an MLAT aircraft but has it supplied a position at some point in the past ?
        if now - ac.last_position_time < self.position_expiry_age:
            return   # It's reported a position recently, so it's not an MLAT

        # OK, looks like it could be an MLAT aircraft so tell the MLAT-Server about it.  Should it
        # provide a position report at a later date we can tell the MLAT-Server that it's not an MLAT
        self.server.send_mlat(message)

    def received_df11(self, message, now):
        # The 360R-Client uses the DF11 messages to actually MLAT the aircraft as these are the most
        # commonly seen non-ADSB message because these are transmitted in response either to ground
        # based interrogations or airborne ones from TCAS units

        # Do we have an aircraft with this address ?
        ac = self.aircraft.get(message.address)
        if not ac:
            # No, so create a new aircrat and store the ICAO hex code
            ac = Aircraft(message.address)
            # Has the MLAT-Server requested details on this aircraft ?
            ac.requested = (message.address in self.requested_traffic)
            # Increment the message count and store when we last saw it
            ac.messages += 1
            ac.last_message_time = now
            # Start measuring the meassage rate for this aircraft
            ac.rate_measurement_start = now
            self.aircraft[message.address] = ac
            # We can't do anything more until we have more messages (one is not enough)
            return

        # Increment the message count and store when we last saw it
        ac.messages += 1
        ac.last_message_time = now

        # How many messages have we seen from it ?
        if ac.messages < 10:
            return   # Not enough so wait for more messages
        # Does the MLAT-Server suspect this is an MLAT aircraft ?
        if not ac.requested:
            return

        # It could be an MLAT aircraft but has it supplied a position at some point in the past ?
        if now - ac.last_position_time < self.position_expiry_age:
            return   # It's reported a position recently, so it's not an MLAT

        # OK, looks like it could be an MLAT aircraft so tell the MLAT-Server about it.  Should it
        # provide a position report at a later date we can tell the MLAT-Server that it's not an MLAT
        self.server.send_mlat(message)

    def received_df17(self, message, now):
        # The 360R-Client uses DF17 messages which contain aircraft positions in order to help sync
        # the receivers

        # Do we have an aircraft with this address ?
        ac = self.aircraft.get(message.address)
        if not ac:
            # No, so create a new aircrat and store the ICAO hex code
            ac = Aircraft(message.address)
            # Has the MLAT-Server requested details on this aircraft ?
            ac.requested = (message.address in self.requested_traffic)
            # Increment the message count and store when we last saw it
            ac.messages += 1
            ac.last_message_time = now
            # Start measuring the meassage rate for this aircraft
            ac.rate_measurement_start = now
            self.aircraft[message.address] = ac
            # We can't do anything more until we have more messages (one is not enough)
            return

        # Increment the message count and store when we last saw it
        ac.messages += 1
        ac.last_message_time = now

        # If it's Airborne Position message, retrieve the altitude value and store it.
        # Also store the aircraft status (Airborne or Surface)
        if (message.tc == 0):
            ac.altitude = message.altitude
            ac.on_ground = False
        elif (message.tc >= 9 and message.tc <= 18):
            ac.altitude = message.altitude
            ac.on_ground = False
        elif (message.tc >= 20 and message.tc <= 22):
            ac.altitude = message.altitude
            ac.on_ground = False
        else:
            ac.on_ground = True

        # Is the aircraft below the altitude cutoff limit or on the ground ?
        if ac.altitude is not None and ac.altitude < self.altitude_limit or ac.on_ground == True:
            self.udpConnection.send(message)
            if DEBUG:
                log("DF{0} TC {1} ALT: {2} {3} from {4} uploaded", message.df, message.tc, ac.altitude, message, message.address)

        # How many messages have we seen from it ?
        if ac.messages < 10:
            return

        # Positions are defined across two messages: an odd message and an even message and
        # we need both to determine the aircraft position
        if not message.even_cpr and not message.odd_cpr:
            # The message isn't a position message so we can't use this one
            return

        # Store when we last saw it
        ac.last_position_time = now

        # We synchronise using altitude messages ?
        if message.altitude is None:
            return    # need an altitude
        # OK, so it's an altitude message but we need a NUCp value >= 6 to continue
        if message.nuc < 6:
            return    # need NUCp >= 6

        # Increment message count
        ac.recent_adsb_positions += 1

        # The MLAT-Server isn't terribly efficient as it can spend more time syncing receivers
        # than actually solving the aircraft positions.  Split-sync _would_ allow the MLAT-Server
        # to be split across a cluster of machines but the current version of the MLAT-Server does
        # not support this.  The FlightAware version does though but that's not public :-(
        if self.server.send_split_sync:
            if not ac.requested:
                return

            # this is a useful reference message
            self.server.send_split_sync(message)
        else:
            # Store message type (odd or even)
            if message.even_cpr:
                ac.even_message = message
            else:
                ac.odd_message = message

            # Does the MLAT-Server suspect this is an MLAT aircraft ?
            if not ac.requested:
                return
            # If it's not an odd or even message just return
            if not ac.even_message or not ac.odd_message:
                return
            # To calculate a valid position we need an odd and an even message no more than
            # 5 seconds apart from the same aircraft.  If we don't get this just return
            if abs(ac.even_message.timestamp - ac.odd_message.timestamp) > 5 * self.freq:
                return

            # This is a useful reference message pair so use them to sync the receiver
            self.server.send_sync(ac.even_message, ac.odd_message)

    def received_modeac(self, message, now):
        # Theoretically we could MLAT a Mode A/C response if we make it look like a valid
        # hex code.  In other words 6402 could be made to look like FF6402 but this function
        # just looks like a placeholder for functionality that may have been added later
        # as this function never seems to get called

        if DEBUG:
            log("Mode A/C message received")

        if message.address not in self.requested_modeac:
            return

        self.server.send_mlat(message)

    def getServer(self):
        # Function to get server to send data to
        rx = self.server.handshake_data['user']
        lat = self.server.handshake_data['lat']
        lon = self.server.handshake_data['lon']
        alt = self.server.handshake_data['alt']

        # Build URL to call
        url = "https://controller.360radar.co.uk/server.php?rx=" + rx + "&amp;lat=" + str(lat) + "&amp;lon=" + str(lon) + "&amp;alt=" + str(alt)

        # Try to request this URL and throw an exception if there's no response
        # after 5 seconds
        try:
            log("Querying controller for MLAT server and altitude limit")
            response = requests.get(url, timeout = 5);

            # Check response from server
            if response.status_code == 200:
                # Decode JSON response
                response.raise_for_status()
                json = response.json()

                # Extract out the ADSB server, port and altitude limit server and port
                newAdsbHost = json['as']
                newAdsbPort = int(json['ap'])
                newAltitude = json["al"]

                # If the ADSB server has changed then use it
                if self.adsbHost != newAdsbHost or self.adsbPort != newAdsbPort:
                    log("New ADSB server: {0}:{1}", newAdsbHost, newAdsbPort)
                    # Store new values
                    self.adsbHost = newAdsbHost
                    self.adsbPort = newAdsbPort
                    # Update UDP uploader with them
                    self.udpConnection.updateServer(self.adsbHost, self.adsbPort)

                # If the altitude limit is different then use it
                if self.altitude_limit != newAltitude:
                    self.altitude_limit = newAltitude
                    log("New ADSB aircraft altitude limit: {} ft", self.altitude_limit)

                # Extract out the new MLAT server and port
                newMlatServer = json["ms"]
                newMlatPort = int(json["mp"])

                # If the MLAT server or port has changed then use them
                if self.server.host != newMlatServer or self.server.port != newMlatPort:

                    # Disconnect
                    self.server.disconnect('Changing MLAT server and/or port so restarting')
                    # Reset the connection
                    self.server.reset_connection()

                    # Update with new values
                    self.server.host = newMlatServer
                    self.server.port = newMlatPort

                    # Reconnect using the new values
                    self.server.reconnect()
            else:
                # Use default value for altitude
                log("Server didn't reply ({}), using previous values", err)

        except HTTPError as http_err:
            log("HTTP error occurred: {}", http_err)

        except Exception as err:
            # We didn't get a reply so use default values
            log("Server didn't reply ({}), using current values for now", err)
